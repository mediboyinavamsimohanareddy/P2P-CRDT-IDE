# MEMORY — DecentraIDE (AI progress tracker)

> **The AI must read this file at the START of every session and update it at the END of every task.**
> It is the only continuity between sessions. Keep it accurate, short, and honest.

## How to use
1. Read `rules.md`, then this file, then the next unchecked task in `task.md`.
2. Work on **one task only**.
3. When finished: tick it below, add a Change Log line, update "Current state" and "Next up".
4. Never tick a task unless its Definition of Done in `task.md` is actually met and verified.

---

## Current state
- **Date last updated:** (fill in)
- **Current phase:** Phase 0 — Project setup
- **Current task:** T-001
- **Last completed task:** none
- **Build status:** not started
- **Tests status:** not started
- **Blocked by:** nothing

## Next up (max 3)
1. T-001 Monorepo setup
2. T-002 App shell + design tokens
3. T-003 Shared types & schemas

---

## Progress checklist (mirror of task.md — tick here when DONE)

### Phase 0 — Setup
- [ ] T-001 · [ ] T-002 · [ ] T-003

### Phase 1 — Local IDE core
- [ ] T-010 · [ ] T-011 · [ ] T-012 · [ ] T-013 · [ ] T-014

### Phase 2 — CRDT core
- [ ] T-020 · [ ] T-021 · [ ] T-022 · [ ] T-023 · [ ] T-024 · [ ] T-025

### Phase 3 — Security
- [ ] T-030 · [ ] T-031 · [ ] T-032 · [ ] T-033 · [ ] T-034 · [ ] T-035 · [ ] T-036

### Phase 4 — Transport + Spring Boot
- [ ] T-040 · [ ] T-041 · [ ] T-042 · [ ] T-043 · [ ] T-044 · [ ] T-045 · [ ] T-046 · [ ] T-047 · [ ] T-048

### Phase 5 — Collaboration UI
- [ ] T-050 · [ ] T-051 · [ ] T-052 · [ ] T-053 · [ ] T-054

### Phase 6 — AI copilot
- [ ] T-060 · [ ] T-061 · [ ] T-062 · [ ] T-063

### Phase 7 — Semantic conflict resolver
- [ ] T-070 · [ ] T-071 · [ ] T-072 · [ ] T-073 · [ ] T-074 · [ ] T-075 · [ ] T-076 · [ ] T-077

### Phase 8 — Security monitor, health, metrics, demo
- [ ] T-080 · [ ] T-081 · [ ] T-082 · [ ] T-083 · [ ] T-084 · [ ] T-085

### Phase 9 — Polish & release
- [ ] T-090 · [ ] T-091 · [ ] T-092 · [ ] T-093 · [ ] T-094

---

## Decisions log (append only)
| Date | Decision | Reason |
|------|----------|--------|
| (init) | CRDT lib = Yjs behind `CrdtEngine` interface | Mature, fast, swappable |
| (init) | Desktop = Electron + React + TS | Monaco, node-pty, fs access |
| (init) | Local AI default = Ollama + Qwen2.5-Coder | Privacy, "ON DEVICE" UI |
| (init) | Crypto = Ed25519 / X25519 / XChaCha20-Poly1305 via libsodium | Standard, audited |

## Known issues / tech debt
- (none yet)

## Deviations from architecture.md / ui.md
- (none yet — any deviation MUST be listed here with a reason)

## Environment notes
- (versions of Node, Java, Maven, Ollama model tag, commands to run each app — fill in during T-001)

## Change log (append newest at bottom)
```
[YYYY-MM-DD] T-XXX DONE — what was built — files touched — tests added/passing — notes
```
